package main

import (
	"math/rand"
	"sync"
	"time"

	"github.com/sirupsen/logrus"
)

// Task represents a unit of work.
type Task struct {
	id         int
	data       string
	retryCount int
}

const maxRetries = 3 // Maximum retry limit for failed tasks

// Worker function that processes tasks. If a worker fails, the task will be sent to failChan.
func worker(id int, taskChan <-chan Task, wg *sync.WaitGroup, doneChan, failChan chan<- Task) {
	defer wg.Done()

	for task := range taskChan {
		logrus.WithFields(logrus.Fields{"worker_id": id, "task_id": task.id, "task_data": task.data}).Info("Started task")

		// Simulate random failure (30% chance of failure)
		if rand.Float32() < 0.3 {
			logrus.WithFields(logrus.Fields{"worker_id": id, "task_id": task.id}).Error("Failed task")
			failChan <- task

			continue
		}
		// Simulate task processing time
		time.Sleep(time.Duration(rand.Intn(3)+1) * time.Second)
		doneChan <- task
		logrus.WithFields(logrus.Fields{"worker_id": id, "task_id": task.id}).Info("Completed task")
	}
}

func main() {

	// Set logrus to output timestamps in text format
	logrus.SetFormatter(&logrus.TextFormatter{FullTimestamp: true})
	logrus.SetLevel(logrus.InfoLevel)

	// Define a set of tasks to be executed
	tasks := []Task{
		{id: 1, data: "Task 1"},
		{id: 2, data: "Task 2"},
		{id: 3, data: "Task 3"},
		{id: 4, data: "Task 4"},
		{id: 5, data: "Task 5"},
	}

	// Channels for task distribution and failure handling
	taskChan := make(chan Task, len(tasks))
	failChan := make(chan Task, len(tasks))
	doneChan := make(chan Task, len(tasks))

	// WaitGroup to ensure all workers finish their tasks
	var wg sync.WaitGroup

	// Number of workers (simulating processors)
	numWorkers := 3

	// Worker goroutines
	for i := 1; i <= numWorkers; i++ {
		wg.Add(1)
		go worker(i, taskChan, &wg, doneChan, failChan)
	}

	// Distribute tasks to the available workers
	go func() {
		for _, task := range tasks {
			logrus.WithFields(logrus.Fields{"task_id": task.id}).Info("Sending task to available worker")
			taskChan <- task // Any available worker will pick it up
		}
	}()

	// Handle failed tasks by redistributing them
	go func() {
		for failedTask := range failChan {
			failedTask.retryCount++
			if failedTask.retryCount > maxRetries {
				logrus.WithFields(logrus.Fields{"task_id": failedTask.id, "retryCount": failedTask.retryCount}).Info("Task failed exceeding max retry limit")
				continue
			}
			taskChan <- failedTask // Send back to the task channel to be retried
			logrus.WithFields(logrus.Fields{"task_id": failedTask.id, "retryCount": failedTask.retryCount}).Info("Reassigning failed task")
		}
	}()

	// Collect completed tasks and close channels when done
	go func() {
		defer close(taskChan)
		defer close(failChan)
		defer close(doneChan)

		completedTasks := 0
		for range doneChan {
			completedTasks++
			if completedTasks == len(tasks) {
				break
			}
		}
	}()

	// Wait for all workers to finish
	wg.Wait()

	logrus.Info("All tasks completed.")
}
